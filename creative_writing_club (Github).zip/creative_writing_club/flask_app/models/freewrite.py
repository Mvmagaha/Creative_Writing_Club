from flask_app.config.mysqlconnection import connectToMySQL
from flask import session
from flask_app.models.user import User

class Freewrite:
    db="cwc"
    def __init__(self, data):
        self.id = data["id"]
        self.freewrite = data["freewrite"]
        self.date = data["date"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
        self.users_id = data["users_id"]

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM freewrites ORDER BY date DESC;"
        results = connectToMySQL(cls.db).query_db(query)
        freewrites = []

        for freewrite in results:
            freewrites.append(cls(freewrite))
        return freewrites
    
    @classmethod
    def get_one(cls, freewrite_id):
        query = "SELECT * FROM freewrites WHERE id=%(id)s;"
        data = {
            "id": freewrite_id
        }
        result = connectToMySQL(cls.db).query_db(query, data)
        return cls(result[0])
    
    @classmethod
    def save(cls, data):
        query = """
        INSERT INTO freewrites (freewrite, date, users_id)
        VALUES (%(freewrite)s, %(date)s, %(users_id)s);
        """
        return connectToMySQL(cls.db).query_db(query, data)
    
    @classmethod
    def update(cls, data):
        query = """
        UPDATE freewrites SET freewrite=%(freewrite)s, date=%(date)s, users_id=%(users_id)s
        WHERE id=%(id)s;
        """
        return connectToMySQL(cls.db).query_db(query, data)
    
    @classmethod
    def delete(cls, freewrite_id):
        data = {
            "id": freewrite_id
        }
        query = "DELETE FROM freewrites WHERE id=%(id)s;"
        return connectToMySQL(cls.db).query_db(query, data)