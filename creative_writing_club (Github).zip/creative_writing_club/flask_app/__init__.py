from flask import Flask

app = Flask(__name__)
app.secret_key = "pints_of_guinness_make_you_strong"