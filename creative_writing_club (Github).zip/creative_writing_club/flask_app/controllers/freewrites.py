from flask import render_template, request, redirect, session
from flask_app import app
from flask_app.models import freewrite
from flask_app.models import user

@app.route("/freewrites/new")
def new_freewrite_form():
    data = {
        'user_id': session['user_id']
    }
    return render_template("new_fw.html", user=data)

@app.route("/freewrites/new", methods=["POST"])
def create_freewrite():
    data = {
        "freewrite": request.form["freewrite"],
        "date": request.form["date"],
        "users_id": session["user_id"]
    }
    freewrite.Freewrite.save(data)
    return redirect("/user_landing")

@app.route("/freewrites/<int:freewrite_id>/view")
def view_freewrite(freewrite_id):
    freewrite_view = freewrite.Freewrite.get_one(freewrite_id)
    return render_template("show_fw.html", freewrite=freewrite_view)

@app.route("/freewrites/<int:freewrite_id>/edit")
def edit_freewrite(freewrite_id):
    freewrite_edit = freewrite.Freewrite.get_one(freewrite_id)
    return render_template("edit_fw.html", freewrite=freewrite_edit)

@app.route("/freewrites/<int:freewrite_id>/update", methods=["POST"])
def update_freewrite(freewrite_id):
    data ={
        "id": freewrite_id,
        "freewrite": request.form["freewrite"],
        "date": request.form["date"],
        "users_id": session["user_id"]
    }
    freewrite.Freewrite.update(data)
    return redirect("/user_landing")

@app.route("/freewrites/<int:freewrite_id>/delete")
def delete_freewrite(freewrite_id):
    freewrite.Freewrite.delete(freewrite_id)
    return redirect('/user_landing')